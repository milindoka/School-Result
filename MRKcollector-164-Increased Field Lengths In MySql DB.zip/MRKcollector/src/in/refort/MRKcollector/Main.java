package in.refort.MRKcollector;

public class Main {
	
	public static void main(String[] args) {
		
		MRKFrame frame = new MRKFrame();
		frame.setVisible(true);
		
		
		// frame = new AppFrame();
	//	frame.setLocationRelativeTo(null); /*centers on screen*/
		//frame.setVisible(true);
		
		// show as a followup part...
		//AppController.getInstance().displayText("<This is & a test./>");
	}

}